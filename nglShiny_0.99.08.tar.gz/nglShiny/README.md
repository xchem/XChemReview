# nglShiny
Alexander Rose's nglviewer as an R/Shiny widget
